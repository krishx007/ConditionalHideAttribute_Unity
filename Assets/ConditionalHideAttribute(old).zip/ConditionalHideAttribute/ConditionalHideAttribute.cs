/**
=====================
Name:			ConditionalHideAttribute.cs
Author:			Brecht Lecluyse, Customised by Krishna Kumar
Update Date:	15, Dec, 2019
Description:	http://www.brechtos.com/hiding-or-disabling-inspector-properties-using-propertydrawers-within-unity-5

Limitation: Currently can't hide array/list in the inspector. But the array/list can be encapsulated in a serialized class to hide it.
=====================
*/

/*
Example:-

[Header("Auto Aim")] //Optional
public bool EnableAutoAim = false;

[ConditionalHide("EnableAutoAim")]
public float Range = 0.0f;

[ConditionalHide("EnableAutoAim")]
public DemoClass ExampleDataClass = new DemoClass();


====C# 6.0 and Higher ====

[Header("Auto Aim")] //Optional
public bool EnableAutoAim = false;

[ConditionalHide(nameof(EnableAutoAim))]
public float Range = 0.0f;

[ConditionalHide(nameof(EnableAutoAim))]
public DemoClass ExampleDataClass = new DemoClass();
*/


using UnityEngine;
using System;
using System.Collections;

[AttributeUsage(AttributeTargets.Field | AttributeTargets.Property |
    AttributeTargets.Class | AttributeTargets.Struct, Inherited = true)]
public class ConditionalHideAttribute : PropertyAttribute
{
    //The name of the bool field that will be in control
    public string ConditionalSourceField = "";
    //TRUE = Hide in inspector / FALSE = Disable in inspector 
    public bool HideInInspector = true;

    public ConditionalHideAttribute(string conditionalSourceField)
    {
        this.ConditionalSourceField = conditionalSourceField;
        this.HideInInspector = true;
    }

    public ConditionalHideAttribute(string conditionalSourceField, bool hideInInspector)
    {
        this.ConditionalSourceField = conditionalSourceField;
        this.HideInInspector = hideInInspector;
    }
}



